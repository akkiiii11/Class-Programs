package com.spring;

public interface Recorder {
	
	void score();

}
