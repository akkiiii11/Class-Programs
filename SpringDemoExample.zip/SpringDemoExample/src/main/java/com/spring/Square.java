package com.spring;

public class Square implements Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
		System.out.println("Drawing a Square.");
		
	}
	
	
}
