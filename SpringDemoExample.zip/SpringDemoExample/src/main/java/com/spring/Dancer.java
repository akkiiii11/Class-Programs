package com.spring;

public class Dancer implements Performer {

	@Override
	public void perform() {
		
		System.out.println("Dancer is Dancing on the Takatak Song.");
		
	}

}
