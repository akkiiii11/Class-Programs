package com.spring;

public interface Performer {
	
	void perform();

}
