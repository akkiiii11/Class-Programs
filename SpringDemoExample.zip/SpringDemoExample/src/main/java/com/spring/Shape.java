package com.spring;

public interface Shape {
	
	void draw();

}
