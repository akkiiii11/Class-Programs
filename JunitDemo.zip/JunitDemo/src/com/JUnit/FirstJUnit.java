package com.JUnit;

public class FirstJUnit {

	public static void main(String[] args) {
		
		

	}

}
