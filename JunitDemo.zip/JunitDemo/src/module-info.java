/**
 * 
 */
/**
 * 
 */
module JunitDemo {
	requires junit;
}