package com.spring;

public class Tea implements HotDrink
{
	@Override
	public void prepareHotDrink() {
		// TODO Auto-generated method stub
		
		System.out.println("Hii... I'm preparing the Tea for You");
	}
}
