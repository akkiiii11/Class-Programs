package com.spring;

public interface HotDrink {
	
	public void prepareHotDrink();

}
