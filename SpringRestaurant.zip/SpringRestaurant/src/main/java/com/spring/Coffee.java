package com.spring;

public class Coffee implements HotDrink
{
	@Override
	public void prepareHotDrink() {
		// TODO Auto-generated method stub
		
		System.out.println("Hii... I'm preparing the Coffee for You");
		
	}

}
